
public interface IGrosseZahl {
	public String toString();
	public boolean less(GrosseZahl b);
	public GrosseZahl add(GrosseZahl b);
	public GrosseZahl mult(GrosseZahl b);
	public GrosseZahl ggT(GrosseZahl b);
}
